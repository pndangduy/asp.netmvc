﻿using BUS;
using DTO;
using System.Web.Mvc;

namespace Assignment_6.Areas.Admin.Controllers
{
    public class PublisherController : Controller
    {
        #region Avariable
        /// <summary>
        /// Initialize publisher BUS
        /// </summary>
        private PublisherBUS publisherBUS = new PublisherBUS();
        /// <summary>
        /// String notify error
        /// </summary>
        private string error = "";
        #endregion

        #region Method
        /// <summary>
        /// Get all publisher to page
        /// </summary>
        /// <returns>Page display info</returns>
        [HttpGet]
        public ActionResult GetAllPublisher()
        {
            return View();
        }

        /// <summary>
        /// Get all publisher
        /// </summary>
        /// <returns>Publisher list type json</returns>
        [HttpGet]
        public JsonResult GetPublishers()
        {
            var publishers = publisherBUS.GetAll(ref error);
            var jsonData = new
            {
                data = publishers
            };

            return Json(jsonData, JsonRequestBehavior.AllowGet);
        }

        /// <summary>
        /// Page create publisher
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public ActionResult CreatePublisher()
        {
            return View();
        }

        /// <summary>
        /// Create publisher
        /// </summary>
        /// <param name="publisher">Input object publisher binding</param>
        /// <returns>Page create publisher after create success</returns>
        [HttpPost]
        public ActionResult CreatePublisher(Publisher publisher)
        {
            bool isCreate = publisherBUS.Create(publisher, ref error);
            if (!isCreate)
                return View("Error");

            ModelState.Clear();
            Response.Write("<script>alert('Thêm thành công')</script>");
            return View();
        }

        /// <summary>
        /// Load detai of object publisher
        /// </summary>
        /// <param name="id">Input publisher id</param>
        /// <returns>Page contain detail object publisher found</returns>
        public ActionResult DetailPublisher(int id)
        {
            var publisher = publisherBUS.GetObjectWithID(id, ref error);

            return View(publisher);
        }
        #endregion
    }
}