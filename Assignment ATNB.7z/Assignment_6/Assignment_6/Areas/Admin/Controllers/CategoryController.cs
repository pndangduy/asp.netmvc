﻿using BUS;
using DTO;
using System.Web.Mvc;

namespace Assignment_6.Areas.Admin.Controllers
{
    public class CategoryController : Controller
    {
        #region Avariable
        /// <summary>
        /// Initialize author BUS
        /// </summary>
        private CategoryBUS categoryBUS = new CategoryBUS();
        /// <summary>
        /// String notify error
        /// </summary>
        private string error = "";
        #endregion

        #region Method
        /// <summary>
        /// Get all category of book to page
        /// </summary>
        /// <returns>Page display info</returns>
        [HttpGet]
        public ActionResult GetAllCategory()
        {
            return View();
        }

        [HttpGet]
        public JsonResult GetCategories()
        {
            var categories = categoryBUS.GetAll(ref error);
            var jsonData = new
            {
                data = categories
            };

            return Json(jsonData, JsonRequestBehavior.AllowGet);
        }
        /// <summary>
        /// Display page create Category
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public ActionResult CreateCategory()
        {
            return View();
        }

        /// <summary>
        /// Create new category
        /// </summary>
        /// <param name="category">Input object category</param>
        /// <returns></returns>
        [HttpPost]
        public ActionResult CreateCategory(Category category)
        {
            bool isCreate = categoryBUS.Create(category, ref error);
            if (!isCreate)
            {
                Response.Write("<script>alert('Thêm không thành công')</script>");
                return View("Error");
            }
            ModelState.Clear();
            Response.Write("<script>alert('Thêm thành công')</script>");
            return View();
        }

        /// <summary>
        /// Load detail of object category found by category id
        /// </summary>
        /// <param name="id">Input category id</param>
        /// <returns>Page contain detail object category</returns>
        [HttpGet]
        public ActionResult DetailCategory(int id)
        {
            var category = categoryBUS.GetObjectWithID(id, ref error);

            return View(category);
        }
        #endregion
    }
}