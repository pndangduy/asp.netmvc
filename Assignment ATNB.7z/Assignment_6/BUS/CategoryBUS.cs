﻿using DAO;
using DTO;
using System;
using System.Collections.Generic;

namespace BUS
{
    public class CategoryBUS : IDataProvider<Category>
    {

        #region Avairable
        /// <summary>
        /// Initialize category DAL
        /// </summary>
        private CategoryDAO categoryDAO = new CategoryDAO();
        #endregion

        /// <summary>
        /// Create new category
        /// </summary>
        /// <param name="obj">Input object category</param>
        /// <param name="error">Notify error when program error</param>
        /// <returns>True : create is success. False : create isn't success</returns>
        public bool Create(Category obj, ref string error)
        {
            return categoryDAO.Create(obj, ref error);
        }

        public bool Del(int id, ref string error)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Get all category of book 
        /// </summary>
        /// <returns>List category</returns>
        public List<Category> GetAll(ref string error)
        {
            return categoryDAO.GetAll(ref error);
        }

        public List<Category> GetAllWithID(int id, ref string error)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Get object category by category id
        /// </summary>
        /// <param name="id">Input category id</param>
        /// <param name="error">Notify error when program error</param>
        /// <returns>Object category after found by id</returns>
        public Category GetObjectWithID(int id, ref string error)
        {
            return categoryDAO.GetObjectWithID(id, ref error);
        }
    }
}
