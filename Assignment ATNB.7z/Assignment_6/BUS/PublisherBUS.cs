﻿using DAO;
using DTO;
using System;
using System.Collections.Generic;

namespace BUS
{
    public class PublisherBUS : IDataProvider<Publisher>
    {
        #region Avariable
        /// <summary>
        /// Initialize publisher DAL
        /// </summary>
        private PublisherDAO publisherDAO = new PublisherDAO();
        #endregion

        #region Method
        /// <summary>
        /// Create new publisher
        /// </summary>
        /// <param name="obj">Input object publisher</param>
        /// <param name="error">Notify error when program error</param>
        /// <returns>True : create is success. False : create isn't success</returns>
        public bool Create(Publisher obj, ref string error)
        {
            return publisherDAO.Create(obj, ref error);
        }

        public bool Del(int id, ref string error)
        {
            return publisherDAO.Del(id, ref error);
        }

        /// <summary>
        /// Get all publisher.
        /// </summary>
        /// <returns>List publisher</returns>
        public List<Publisher> GetAll(ref string error)
        {
            return publisherDAO.GetAll(ref error);
        }

        public List<Publisher> GetAllWithID(int id, ref string error)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Get object publisher by publisher ID
        /// </summary>
        /// <param name="id">Input publisher ID</param>
        /// <param name="error">Notify error when program error</param>
        /// <returns>Object publisher after found by publisher id</returns>
        public Publisher GetObjectWithID(int id, ref string error)
        {
            return publisherDAO.GetObjectWithID(id, ref error);
        }

        #endregion
    }
}
