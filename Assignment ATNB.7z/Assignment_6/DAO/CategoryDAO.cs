﻿using DTO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace DAO
{
    public class CategoryDAO : IDataProvider<Category>
    {

        /// <summary>
        /// Create new category
        /// </summary>
        /// <param name="obj">Input object category</param>
        /// <param name="error">Notify error when program error</param>
        /// <returns>True : create is success. False : create isn't success</returns>
        public bool Create(Category obj, ref string error)
        {
            try
            {
                return DataProvider.Instance.QueryStoreProduce("SP_CreateCategory", ref error,
                                                                new SqlParameter("CategoryName", obj.CateName),
                                                                new SqlParameter("Description", obj.Description));
            }
            catch (SqlException ex)
            {
                error = ex.Message;
            }
            return false;
        }

        public bool Del(int id, ref string error)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Get all category of book
        /// </summary>
        /// <returns>Category list</returns>
        public List<Category> GetAll(ref string error)
        {
            List<Category> categoryList = new List<Category>();

            try
            {
                foreach (DataRow row in DataProvider.Instance.StoreProduceDataTable("dbo.SP_GetAllCategory",ref error).Rows)
                {
                    categoryList.Add(new Category((int)row[0], (string)row[1], (string)row[2]));
                }
            }
            catch (SqlException ex)
            {
                error = ex.Message;
                return null;
            }

            return categoryList;
        }

        /// <summary>
        /// Get object category by category id
        /// </summary>
        /// <param name="id">Input category id</param>
        /// <param name="error">Notify error when program error</param>
        /// <returns>Object category after found by id</returns>
        public Category GetObjectWithID(int id, ref string error)
        {
            Category category = new Category();

            try
            {
                foreach (DataRow row in DataProvider.Instance.StoreProduceDataTable("SP_GetCategoryByID", ref error, new SqlParameter("CategoryID", id)).Rows)
                {
                    return new Category((int)row[0], (string)row[1], (string)row[2]);
                }
            }
            catch (SqlException ex)
            {
                error = ex.Message;
            }
            catch (Exception ex)
            {
                error = ex.Message;
            }
            return null;
        }
    }
}
