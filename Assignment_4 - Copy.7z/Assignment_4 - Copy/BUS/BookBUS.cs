﻿using DAL;
using DTO;
using System;
using System.Collections.Generic;

namespace BUS
{
    public class BookBUS : IDataProvider<Book>
    {
        #region Avariable
        public BookDAL bookDAL = new BookDAL();

        #endregion

        #region Method

        public bool Create(Book obj, ref string error)
        {
            return bookDAL.Create(obj, ref error);
        }

        public bool Del(int id, ref string error)
        {
            return bookDAL.Del(id, ref error);
        }

        /// <summary>
        /// Get all book 
        /// </summary>
        /// <returns>List book</returns>
        public List<Book> GetAll()
        {
            return bookDAL.GetAll();
        }

        public List<Book> GetAllWithID(int id, ref string error)
        {
            throw new NotImplementedException();
        }

        public Book GetObjectWithID(int id, ref string error)
        {
            return bookDAL.GetObjectWithID(id, ref error);
        }
        #endregion
    }
}
