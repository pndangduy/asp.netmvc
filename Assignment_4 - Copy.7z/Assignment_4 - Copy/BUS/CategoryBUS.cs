﻿using DAL;
using DTO;
using System;
using System.Collections.Generic;

namespace BUS
{
    public class CategoryBUS : IDataProvider<Category>
    {

        #region Avairable
        /// <summary>
        /// Initialize category DAL
        /// </summary>
        private CategoryDAL categoryDAL = new CategoryDAL();
        #endregion

        public bool Create(Category obj, ref string error)
        {
            throw new NotImplementedException();
        }

        public bool Del(int id, ref string error)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Get all category of book 
        /// </summary>
        /// <returns>List category</returns>
        public List<Category> GetAll()
        {
            return categoryDAL.GetAll();
        }

        public List<Category> GetAllWithID(int id, ref string error)
        {
            throw new NotImplementedException();
        }

        public Category GetObjectWithID(int id, ref string error)
        {
            throw new NotImplementedException();
        }
    }
}
