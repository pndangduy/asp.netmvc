﻿using DAL;
using DTO;
using System;
using System.Collections.Generic;

namespace BUS
{
    public class PublisherBUS : IDataProvider<Publisher>
    {
        #region Avariable
        /// <summary>
        /// Initialize publisher DAL
        /// </summary>
        private PublisherDAL publisherDAL = new PublisherDAL();
        #endregion

        #region Method

        public bool Create(Publisher obj, ref string error)
        {
            return publisherDAL.Create(obj, ref error);
        }

        public bool Del(int id, ref string error)
        {
            return publisherDAL.Del(id, ref error);
        }

        /// <summary>
        /// Get all publisher 
        /// </summary>
        /// <returns>List publisher</returns>
        public List<Publisher> GetAll()
        {
            return publisherDAL.GetAll();
        }

        public List<Publisher> GetAllWithID(int id, ref string error)
        {
            throw new NotImplementedException();
        }

        public Publisher GetObjectWithID(int id, ref string error)
        {
            return publisherDAL.GetObjectWithID(id, ref error);
        }

        #endregion
    }
}
