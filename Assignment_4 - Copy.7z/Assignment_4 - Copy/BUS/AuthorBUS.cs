﻿using DTO;
using System;
using System.Collections.Generic;
using DAL;

namespace BUS
{
    public class AuthorBUS
    {
        #region Avariable
        /// <summary>
        /// Initialize new author DAL
        /// </summary>
        public AuthorDAL authorDAL = new AuthorDAL();

        #endregion

        /// <summary>
        /// Get all author 
        /// </summary>
        /// <returns>List author</returns>
        public List<Author> GetAllAuthor()
        {
            return authorDAL.GetAllAuthor();
        }

        /// <summary>
        /// Find object author in author list by input author id
        /// </summary>
        /// <param name="authorID">Input author id</param>
        /// <param name="error">Notify error when program error</param>
        /// <returns>Object author after found in author list</returns>
        public Author FindAuthorWithID(int authorID, ref string error)
        {
            if (String.IsNullOrEmpty(authorID.ToString()))
            {
                error = "Author id is empty";
                return null;
            }
            return authorDAL.FindAuthorWithID(authorID, ref error);
        }

        /// <summary>
        /// Create new object author to author list.
        /// </summary>
        /// <param name="author">Input author.</param>
        /// <param name="error">Error notify when program error.</param>
        /// <returns>True : add author is success. False : add author isn't success.</returns>
        public bool CreateAuthor(Author author, ref string error)
        {
            if (author == null)
            {
                error = "Object author input is null";
                return false;
            }

            return authorDAL.CreateAuthor(author, ref error);
        }

        /// <summary>
        ///  Edit infor of object author.
        /// </summary>
        /// <param name="authorID">Input id of author.</param>
        /// <param name="authorName">Input name of author.</param>
        /// <param name="history">Input history of author.</param>
        /// <param name="error">Notify error when program error.</param>
        /// <returns>True : edit is success. False : edit isn't success.</returns>
        public bool EditAuthor(int authorID, string authorName, string history, ref string error)
        {
            if (String.IsNullOrEmpty(authorID.ToString()) ||
                String.IsNullOrEmpty(authorName) ||
                String.IsNullOrEmpty(history))
            {
                error = "Input isn't empty";
                return false;
            }

            return authorDAL.EditAuthor(authorID, authorName, history, ref error);
        }

        /// <summary>
        /// Delete one object author in author list.
        /// </summary>
        /// <param name="authorID">Input id of author.</param>
        /// <param name="error">Notify error when program error.</param>
        /// <returns>True : delete is success. False : delete isn't success.</returns>
        public bool DelAuthor(int authorID, ref string error)
        {
            if (String.IsNullOrEmpty(authorID.ToString()))
            {
                error = "Author id is empty";
                return false;
            }

            return authorDAL.DelAuthor(authorID, ref error);
        }
    }
}
