﻿(function (global) {
    "use strict;"

    $(document).ready(function () {
        let 
            $crudBookForm = $("#crud-book-form")
            ;

        $crudBookForm.validate({
            messages: {
                //title: "Please enter the title",
                //sumary: "Please enter the sumary",
                //price: "Please enter the price",
                //quantity: "Please enter the quantity"
            },
            errorElement: "div",
            errorPlacement: function (error, element) {
                error.addClass("invalid-feedback");

                error.insertAfter(element);
            },
            highlight: function (element, errorClass, validClass) {
                $(element).parents("form").addClass("was-validated");
            },
            unhighlight: function (element, errorClass, validClass) {
            }
        });

        //$('#books-table').DataTable({
        //    "ajax": "jsons/book.json",
        //    "columnDefs": [{
        //        "targets": 5,
        //        "data": null,
        //        "defaultContent": `<a href="#">Edit</a> |
        //                        <a href="#">Details</a> |
        //                        <a href="#">Delete</a>`
        //    }],
        //    "columns": [
        //        { "data": "Title" },
        //        { "data": "Price" },
        //        { "data": "Quantity" },
        //        { "data": "ImageUrl" },
        //        { "data": "IsActive" }
        //    ]
        //});
    });
})((this || 0).self || global);