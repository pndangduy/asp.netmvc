﻿using BUS;
using DTO;
using System.Web.Mvc;

namespace Assignment_3.Areas.Admin.Controllers
{
    public class PublisherController : Controller
    {
        #region Avariable
        /// <summary>
        /// Initialize publisher BUS
        /// </summary>
        private PublisherBUS publisherBUS = new PublisherBUS();
        /// <summary>
        /// String notify error
        /// </summary>
        private string error = "";
        #endregion

        #region Method
        /// <summary>
        /// Get all publisher to page
        /// </summary>
        /// <returns>Page display info</returns>
        [HttpGet]
        public ActionResult GetAllPublisher()
        {
            return View(publisherBUS.GetAll());
        }

        [HttpGet]
        public ActionResult CreatePublisher()
        {
            return View();
        }

        [HttpPost]
        public ActionResult CreatePublisher(Publisher publisher)
        {
            bool isCreate = publisherBUS.Create(publisher, ref error);
            if (!isCreate)
                return View("Error");
            return View();
        }
        #endregion
    }
}