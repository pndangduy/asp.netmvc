﻿using BUS;
using DTO;
using System.Web.Mvc;

namespace Assignment_3.Areas.Admin.Controllers
{
    public class BookController : Controller
    {
        #region Avaiable 
        /// <summary>
        /// Initialize book BUS
        /// </summary>
        public BookBUS bookBUS = new BookBUS();
        /// <summary>
        /// String notify error
        /// </summary>
        private string error = "";
        #endregion

        #region Method
        /// <summary>
        /// Get all book to page
        /// </summary>
        /// <returns>Page display info</returns>
        public ActionResult GetAllBook()
        {
            return View(bookBUS.GetAll());
        }

        [HttpGet]
        public ActionResult CreateBook()
        {
            return View();
        }

        [HttpPost]
        public ActionResult CreateBook(Book book)
        {
            bool isCreate = bookBUS.Create(book, ref error);
            if (!isCreate)
                return View("Error");
            return View();
        }

        public ActionResult DeleteBook(int bookID)
        {
            bool isDelete = bookBUS.Del(bookID, ref error);
            if (!isDelete)
                return View("Error");
            return PartialView("GetAllBook");
        }
        #endregion
    }
}