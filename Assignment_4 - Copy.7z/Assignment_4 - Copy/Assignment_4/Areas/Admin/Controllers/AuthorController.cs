﻿using BUS;
using DTO;
using System.Web.Mvc;

namespace Assignment_3.Areas.Admin.Controllers
{
    public class AuthorController : Controller
    {

        #region Avariable 
        /// <summary>
        /// Initialize author BUS
        /// </summary>
        private AuthorBUS authorBUS = new AuthorBUS();
        /// <summary>
        /// String notify error
        /// </summary>
        private string error = "";
        #endregion

        #region Method
        /// <summary>
        /// Get all author to page
        /// </summary>
        /// <returns>Page display all author</returns>
        public ActionResult GetAllAuthor()
        {
            return View(authorBUS.GetAllAuthor());
        }

        [HttpGet]
        public ActionResult CreateAuthor()
        {
            return View();
        }

        [HttpPost]
        public ActionResult CreateAuthor(Author author)
        {
            if (author == null)
            {
                return View("Error");
            }

            bool isCreate = authorBUS.CreateAuthor(author, ref error);
            if (isCreate)
                return View();
            return View("Error");
        }

        public ActionResult EditAuthor()
        {
            return View();
        }

        [HttpGet]
        public ActionResult DetailAuthor(int id)
        {
            return View(authorBUS.FindAuthorWithID(id,ref error));
        }

        public ActionResult DeleteAuthor()
        {
            return View();
        }
        #endregion
    }
}