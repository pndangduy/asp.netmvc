﻿using BUS;
using System.Web.Mvc;

namespace Assignment_3.Areas.Admin.Controllers
{
    public class CategoryController : Controller
    {
        #region Avariable
        /// <summary>
        /// Initialize author BUS
        /// </summary>
        private CategoryBUS categoryBUS = new CategoryBUS();
        /// <summary>
        /// String notify error
        /// </summary>
        //private string error = "";
        #endregion

        #region Method
        /// <summary>
        /// Get all category of book to page
        /// </summary>
        /// <returns>Page display info</returns>
        [HttpGet]
        public ActionResult GetAllCategory()
        {
            return View(categoryBUS.GetAll());
        }
        #endregion
    }
}