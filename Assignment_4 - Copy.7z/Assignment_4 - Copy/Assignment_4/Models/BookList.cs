﻿using DTO;

namespace Assignment_4.Models
{
    public class BookList
    {
        public int BookID { get; set; }
        public string Title { get; set; }
        public string Image { get; set; }
        public string AuthorName { get; set; }
        public string Summary { get; set; }
        public float Price { get; set; }
    }
}