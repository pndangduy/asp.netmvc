﻿using Assignment_4.Models;
using BUS;
using System.Linq;
using System.Web.Mvc;

namespace Assignment_4.Controllers
{
    public class HomeController : Controller
    {

        #region Avariable
        public AuthorBUS authorBUS = new AuthorBUS();
        public CategoryBUS categoryBUS = new CategoryBUS();
        public BookBUS bookBUS = new BookBUS();
        #endregion

        public ActionResult Main()
        {
            var authorList = authorBUS.GetAllAuthor();

            var bookList = bookBUS.GetAll();

            var resultList = (from a in authorList
                              join b in bookList
                              on a.AuthorID equals b.AuthorID
                              select new BookList
                              {
                                  BookID = b.BookID,
                                  Title = b.Title,
                                  Image = b.ImgUrl,
                                  AuthorName = a.AuthorName,
                                  Summary = b.Summary,
                                  Price = b.Price
                              }).ToList();

            Session["Username"] = AccountController.Username;

            return View(resultList);
        }

        [HttpGet]
        public PartialViewResult GetAllAuthor()
        {
            return PartialView("GetAllAuthor",authorBUS.GetAllAuthor());
        }

        [HttpGet]
        public PartialViewResult GetAllCategory()
        {
            return PartialView("GetAllCategory", categoryBUS.GetAll());
        }
    }
}