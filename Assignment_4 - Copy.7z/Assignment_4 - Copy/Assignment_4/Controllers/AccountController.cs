﻿using DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace Assignment_4.Controllers
{
    public class AccountController : Controller
    {

        #region Avariable
        public static string Username = string.Empty;
        #endregion

        #region Method

        [HttpGet]
        public ActionResult Login()
        {
            return View();
        }

        public ActionResult Login(User user)
        {
            if (user.UserName == "admin" && user.Password == "admin")
            {
                Username = "admin";
                return RedirectToAction("Main", "Home");
            }

            return View();
        }

        public ActionResult Role()
        {
            return PartialView("~/Areas/Admin/Views/Admin/Index.cshtml");
        }

        #endregion
    }
}