﻿using DTO;
using System;
using System.Collections.Generic;

namespace DAL
{
    public class PublisherDAL : IDataProvider<Publisher>
    {
        #region Avairable
        /// <summary>
        /// Initialize hard publisher list
        /// </summary>
        private static List<Publisher> publisherList = new List<Publisher>()
        {
            new Publisher(1,"Publisher 1","Description ..."),
            new Publisher(2,"Publisher 1","Description ..."),
            new Publisher(3,"Publisher 1","Description ..."),
            new Publisher(4,"Publisher 1","Description ..."),
            new Publisher(5,"Publisher 1","Description ..."),
            new Publisher(6,"Publisher 1","Description ..."),
            new Publisher(7,"Publisher 1","Description ..."),
        };
        #endregion

        public bool Create(Publisher obj, ref string error)
        {
            throw new NotImplementedException();
        }

        public bool Del(int id, ref string error)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Get all publisher
        /// </summary>
        /// <returns>Publisher list</returns>
        public List<Publisher> GetAll()
        {
            return publisherList;
        }

        public List<Publisher> GetAllWithID(int id, ref string error)
        {
            throw new NotImplementedException();
        }

        public Publisher GetObjectWithID(int id, ref string error)
        {
            throw new NotImplementedException();
        }
    }
}
