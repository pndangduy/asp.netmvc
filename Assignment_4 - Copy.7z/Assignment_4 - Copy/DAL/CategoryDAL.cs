﻿using DTO;
using System;
using System.Collections.Generic;

namespace DAL
{
    public class CategoryDAL : IDataProvider<Category>
    {

        #region Avariable
        /// <summary>
        /// Initialize hard book list
        /// </summary>
        private static List<Category> categoryList = new List<Category>()
        {
            new Category(1,"Sách ngoại văn","Description...",true),
            new Category(2,"Sách kinh tế","Description...",true),
            new Category(3,"Sách văn học trong nước","Description...",true),
            new Category(4,"Sách văn học nước ngoài","Description...",true),
            new Category(5,"Sách thiếu nhi","Description...",true),
        };
        #endregion

        public bool Create(Category obj, ref string error)
        {
            throw new NotImplementedException();
        }

        public bool Del(int id, ref string error)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Get all category of book
        /// </summary>
        /// <returns>Category list</returns>
        public List<Category> GetAll()
        {
            return categoryList;
        }

        public List<Category> GetAllWithID(int id, ref string error)
        {
            throw new NotImplementedException();
        }

        public Category GetObjectWithID(int id, ref string error)
        {
            throw new NotImplementedException();
        }
    }
}
