﻿using System;
using System.Collections.Generic;
using System.Linq;
using DTO;

namespace DAL
{
    /// <summary>
    /// Data access of author
    /// </summary>
    public class AuthorDAL
    {
        /// <summary>
        /// Initialize hard author list.
        /// </summary>
        public static List<Author> authorList = new List<Author>()
        {
                new Author(1,"Kim Dung","Sinh năm .... mất năm ...."),
                new Author(2,"Lữ Bố","Sinh năm .... mất năm ...."),
                new Author(3,"Nguyễn Du","Sinh năm .... mất năm ...."),
                new Author(4,"Tào Tháo","Sinh năm .... mất năm ...."),
                new Author(5,"Hồ Chí Minh","Sinh năm .... mất năm ...."),
                new Author(6,"Xuân Quỳnh","Sinh năm .... mất năm ...."),
                new Author(7,"Tác giả 7","Sinh năm .... mất năm ...."),
                new Author(8,"Tác giả 8","Sinh năm .... mất năm ...."),
                new Author(9,"Tác giả 9","Sinh năm .... mất năm ....")
        };

        /// <summary>
        /// Get all author.
        /// </summary>
        /// <returns>List author hard code.</returns>
        public List<Author> GetAllAuthor()
        {
            return authorList;
        }

        /// <summary>
        /// Find one object author in author list by input author id.
        /// </summary>
        /// <param name="authorID">Input author id.</param>
        /// <param name="error">Notify error when program error.</param>
        /// <returns>Object author after found in author list.</returns>
        public Author FindAuthorWithID(int authorID,ref string error)
        {
            try
            {
                return authorList.FirstOrDefault(x => x.AuthorID == authorID);
            }
            catch (Exception ex)
            {
                error = ex.Message;
            }
            return null;
        }

        /// <summary>
        /// Create new object author to author list.
        /// </summary>
        /// <param name="author">Input author.</param>
        /// <param name="error">Error notify when program error.</param>
        /// <returns>True : add author is success. False : add author isn't success.</returns>
        public bool CreateAuthor(Author author,ref string error)
        {
            try
            {
                authorList.Add(author);
            }
            catch (Exception ex)
            {
                error = ex.Message;
                return false;
            }
            return true;
        }


        /// <summary>
        ///  Edit infor of object author.
        /// </summary>
        /// <param name="authorID">Input id of author.</param>
        /// <param name="authorName">Input name of author.</param>
        /// <param name="history">Input history of author.</param>
        /// <param name="error">Notify error when program error.</param>
        /// <returns>True : edit is success. False : edit isn't success.</returns>
        public bool EditAuthor(int authorID,string authorName,string history,ref string error)
        {
            try
            {
                var author = FindAuthorWithID(authorID, ref error);
                author.AuthorName = authorName;
                author.History = history;
            }
            catch (Exception ex)
            {
                error = ex.Message;
                return false;
            }
            return true;
        }

        
        /// <summary>
        /// Delete one object author in author list.
        /// </summary>
        /// <param name="authorID">Input id of author.</param>
        /// <param name="error">Notify error when program error.</param>
        /// <returns>True : delete is success. False : delete isn't success.</returns>
        public bool DelAuthor(int authorID ,ref string error)
        {
            try
            {
                var author = FindAuthorWithID(authorID, ref error);
                authorList.Remove(author);
            }
            catch (Exception ex)
            {
                error = ex.Message;
                return false;
            }
            return true;
        }
    }
}
