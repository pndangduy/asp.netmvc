﻿using DTO;
using System;
using System.Collections.Generic;
using System.Linq;

namespace DAL
{
    public class BookDAL : IDataProvider<Book>
    {

        #region Avairable
        /// <summary>
        /// Initialize hard book list
        /// </summary>
        public List<Book> bookList = new List<Book>()
        {
            new Book(1,"Thần điêu đại hiệp","Summary....",1,1,2,125,50,"",true),
            new Book(2,"Title 2","Summary....",4,2,3,25,50,"",true),
            new Book(3,"Title 3","Summary....",2,1,2,23,50,"",true),
            new Book(4,"Title 4","Summary....",3,4,1,20,50,"",true),
            new Book(5,"Title 5","Summary....",1,2,2,30,50,"",true),
            new Book(6,"Title 6","Summary....",2,1,3,100,50,"",true),
            new Book(7,"Title 7","Summary....",3,4,1,142,50,"",true),
            new Book(8,"Title 8","Summary....",1,3,2,160,50,"",true),
        };
        #endregion

        #region Method
        /// <summary>
        /// Get all book.
        /// </summary>
        /// <returns>Book list.</returns>
        public List<Book> GetAll()
        {
            return bookList;
        }

        public List<Book> GetAllWithID(int id, ref string error)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Find object book in book list by book id.
        /// </summary>
        /// <param name="id">ID of book</param>
        /// <param name="error">Notify error when program error.</param>
        /// <returns>Object book after found in book list.</returns>
        public Book GetObjectWithID(int id, ref string error)
        {
            try
            {
                return bookList.FirstOrDefault(x => x.BookID == id);
            }
            catch (Exception ex)
            {
                error = ex.Message;
            }
            return null;
        }

        /// <summary>
        /// Create book.
        /// </summary>
        /// <param name="obj">Input object book to create new.</param>
        /// <param name="error">Notify error when program error.</param>
        /// <returns>True : create is success. False : create isn't success.</returns>
        public bool Create(Book obj, ref string error)
        {
            try
            {
                bookList.Add(obj);
            }
            catch (Exception ex)
            {
                error = ex.Message;
                return false;
            }
            return true;
        }

        /// <summary>
        /// Get object book want remove by book id.
        /// Remove object book found in book list.
        /// </summary>
        /// <param name="id">Input id of book.</param>
        /// <param name="error">Notify error when program error.</param>
        /// <returns>True : delete is success. False : delete isn't success.</returns>
        public bool Del(int id, ref string error)
        {
            try
            {
                Book book = GetObjectWithID(id, ref error);
                bookList.Remove(book);
            }
            catch (Exception ex)
            {
                error = ex.Message;
                return false;
            }
            return true;
        }

        #endregion
    }
}
