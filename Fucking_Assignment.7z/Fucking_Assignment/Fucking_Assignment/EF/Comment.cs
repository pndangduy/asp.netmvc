namespace Fucking_Assignment.EF
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    [Table("Comment")]
    public partial class Comment
    {
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int CommentId { get; set; }

        public int BookId { get; set; }

        [StringLength(350)]
        public string Content { get; set; }

        public DateTime? CreatedDate { get; set; }

        public bool IsActive { get; set; }

        public virtual Book Book { get; set; }
    }
}
