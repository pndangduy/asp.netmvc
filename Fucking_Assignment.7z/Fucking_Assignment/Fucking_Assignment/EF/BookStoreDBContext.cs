namespace Fucking_Assignment.EF
{
	using System;
	using System.Data.Entity;
	using System.ComponentModel.DataAnnotations.Schema;
	using System.Linq;

	public partial class BookStoreDBContext : DbContext
	{
		public BookStoreDBContext()
			: base("name=BookStoreDBContext1")
		{
		}

		public virtual DbSet<Author> Authors { get; set; }
		public virtual DbSet<Book> Books { get; set; }
		public virtual DbSet<Category> Categories { get; set; }
		public virtual DbSet<Comment> Comments { get; set; }
		public virtual DbSet<Publisher> Publishers { get; set; }
		public virtual DbSet<User> Users { get; set; }

		protected override void OnModelCreating(DbModelBuilder modelBuilder)
		{
			modelBuilder.Entity<Author>()
				.HasMany(e => e.Books)
				.WithRequired(e => e.Author)
				.WillCascadeOnDelete(false);

			modelBuilder.Entity<Book>()
				.Property(e => e.Price)
				.HasPrecision(19, 4);

			modelBuilder.Entity<Book>()
				.HasMany(e => e.Comments)
				.WithRequired(e => e.Book)
				.WillCascadeOnDelete(false);

			modelBuilder.Entity<Category>()
				.HasMany(e => e.Books)
				.WithRequired(e => e.Category)
				.WillCascadeOnDelete(false);

			modelBuilder.Entity<Publisher>()
				.HasMany(e => e.Books)
				.WithRequired(e => e.Publisher)
				.WillCascadeOnDelete(false);
		}
	}
}
